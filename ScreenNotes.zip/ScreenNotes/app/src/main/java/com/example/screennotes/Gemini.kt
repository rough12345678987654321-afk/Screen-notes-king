package com.example.screennotes

import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

/** Calls Google's Gemini API (free tier). Get a key at https://aistudio.google.com/apikey */
object Gemini {
    // If Google retires this model name, change it here.
    private const val MODEL = "gemini-2.5-flash"

    private const val PROMPT = """You are an expert note-taker. Below is text extracted by OCR from consecutive 
slides/screens of a lecture or video, in order. OCR may contain errors; fix them using context.
Produce clean, well-structured study notes in Markdown: a title, headings per topic, bullet points, 
key definitions in bold, formulas/steps preserved, and a short summary at the end. 
Mention "[Screenshot N]" where a slide's visual matters. Do not invent facts.

SLIDES:
"""

    fun makeNotes(apiKey: String, slidesText: String): String {
        val conn = URL("https://generativelanguage.googleapis.com/v1beta/models/$MODEL:generateContent")
            .openConnection() as HttpURLConnection
        conn.requestMethod = "POST"
        conn.setRequestProperty("Content-Type", "application/json")
        conn.setRequestProperty("x-goog-api-key", apiKey)
        conn.doOutput = true
        conn.connectTimeout = 30000
        conn.readTimeout = 120000

        val body = JSONObject().put(
            "contents", JSONArray().put(
                JSONObject().put("parts", JSONArray().put(JSONObject().put("text", PROMPT + slidesText)))
            )
        )
        conn.outputStream.use { it.write(body.toString().toByteArray()) }

        val ok = conn.responseCode in 200..299
        val reply = (if (ok) conn.inputStream else conn.errorStream).bufferedReader().readText()
        if (!ok) return "Gemini error ${conn.responseCode}: $reply"

        return JSONObject(reply).getJSONArray("candidates").getJSONObject(0)
            .getJSONObject("content").getJSONArray("parts").getJSONObject(0).getString("text")
    }
}
