package com.example.screennotes

import android.app.*
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.Bitmap
import android.graphics.PixelFormat
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.latin.TextRecognizerOptions
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.MutableStateFlow
import java.io.File
import kotlin.math.abs
import kotlin.math.max

/**
 * Watches the screen ~1.4 times per second. When the screen CHANGES and then SETTLES
 * (a new slide, a revealed answer, a new page), it saves a screenshot + reads its text.
 */
class CaptureService : Service() {

    companion object {
        val running = MutableStateFlow(false)
        const val ACTION_STOP = "stop"

        // --- Tuning knobs (try changing these if it saves too much / too little) ---
        const val TICK_MS = 700L          // how often we look at the screen
        const val MOVING_THRESHOLD = 3.0  // bigger change than this = screen still changing (video/animation)
        const val NEW_THRESHOLD = 4.0     // settled screen differing this much from last save = new slide
        const val SETTLE_TICKS = 2        // screen must stay still this many ticks before saving
    }

    private var projection: MediaProjection? = null
    private var reader: ImageReader? = null
    private var display: VirtualDisplay? = null
    private val handler = Handler(Looper.getMainLooper())
    private val scope = CoroutineScope(Dispatchers.IO + SupervisorJob())

    private var noteId = 0L
    private var startMs = 0L
    private var w = 0
    private var h = 0
    private var lastSaved: IntArray? = null
    private var lastFrame: IntArray? = null
    private var stableTicks = 0

    private val tick = object : Runnable {
        override fun run() {
            try { grab() } catch (_: Exception) { }
            handler.postDelayed(this, TICK_MS)
        }
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) { stopSelf(); return START_NOT_STICKY }
        if (running.value) return START_NOT_STICKY

        startForegroundNow()

        val code = intent?.getIntExtra("code", 0) ?: 0
        @Suppress("DEPRECATION")
        val data = intent?.getParcelableExtra<Intent>("data") ?: run { stopSelf(); return START_NOT_STICKY }

        val mpm = getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        projection = mpm.getMediaProjection(code, data)
        projection?.registerCallback(object : MediaProjection.Callback() {
            override fun onStop() { stopSelf() }
        }, handler)

        val dm = resources.displayMetrics
        val scale = 1280f / max(dm.widthPixels, dm.heightPixels)
        w = (dm.widthPixels * scale).toInt()
        h = (dm.heightPixels * scale).toInt()

        reader = ImageReader.newInstance(w, h, PixelFormat.RGBA_8888, 2)
        display = projection?.createVirtualDisplay(
            "ScreenNotes", w, h, dm.densityDpi,
            DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR, reader!!.surface, null, null
        )

        startMs = System.currentTimeMillis()
        scope.launch {
            val title = "Session " + java.text.SimpleDateFormat("d MMM, HH:mm", java.util.Locale.getDefault())
                .format(java.util.Date(startMs))
            noteId = AppDb.get(this@CaptureService).dao().insertNote(Note(title = title, createdAt = startMs))
        }
        running.value = true
        handler.postDelayed(tick, 1000)
        return START_NOT_STICKY
    }

    private fun startForegroundNow() {
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel("cap", "Capture", NotificationManager.IMPORTANCE_LOW))
        val stop = PendingIntent.getService(
            this, 0, Intent(this, CaptureService::class.java).setAction(ACTION_STOP),
            PendingIntent.FLAG_IMMUTABLE
        )
        val n = Notification.Builder(this, "cap")
            .setContentTitle("Screen Notes is capturing")
            .setContentText("Tap Stop when your lecture ends")
            .setSmallIcon(android.R.drawable.ic_menu_camera)
            .addAction(Notification.Action.Builder(null, "Stop", stop).build())
            .build()
        startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION)
    }

    private fun grab() {
        if (noteId == 0L) return
        val img = reader?.acquireLatestImage() ?: return
        val plane = img.planes[0]
        val rowPixels = plane.rowStride / plane.pixelStride
        val full = Bitmap.createBitmap(rowPixels, h, Bitmap.Config.ARGB_8888)
        full.copyPixelsFromBuffer(plane.buffer)
        img.close()
        val bmp = Bitmap.createBitmap(full, 0, 0, w, h)

        val sig = signature(bmp)
        val prev = lastFrame
        lastFrame = sig

        if (prev != null && diff(prev, sig) > MOVING_THRESHOLD) {
            stableTicks = 0            // still moving, wait until it settles
            return
        }
        stableTicks++
        if (stableTicks == SETTLE_TICKS) {
            val ref = lastSaved
            if (ref == null || diff(ref, sig) > NEW_THRESHOLD) {
                lastSaved = sig
                save(bmp)
            }
        }
    }

    /** Tiny 32x18 grayscale fingerprint of the screen. */
    private fun signature(b: Bitmap): IntArray {
        val s = Bitmap.createScaledBitmap(b, 32, 18, true)
        val px = IntArray(32 * 18)
        s.getPixels(px, 0, 32, 0, 0, 32, 18)
        return IntArray(px.size) {
            val c = px[it]
            (((c shr 16) and 0xFF) * 3 + ((c shr 8) and 0xFF) * 6 + (c and 0xFF)) / 10
        }
    }

    private fun diff(a: IntArray, b: IntArray): Double {
        var sum = 0L
        for (i in a.indices) sum += abs(a[i] - b[i])
        return sum.toDouble() / a.size
    }

    private fun save(bmp: Bitmap) {
        val t = System.currentTimeMillis() - startMs
        val id = noteId
        scope.launch {
            val dir = File(filesDir, "shots/$id").apply { mkdirs() }
            val f = File(dir, "${t}.jpg")
            f.outputStream().use { bmp.compress(Bitmap.CompressFormat.JPEG, 92, it) }

            TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS)
                .process(InputImage.fromBitmap(bmp, 0))
                .addOnCompleteListener { task ->
                    val text = if (task.isSuccessful) task.result.text else ""
                    scope.launch {
                        AppDb.get(this@CaptureService).dao()
                            .insertShot(Shot(noteId = id, path = f.absolutePath, ocrText = text, timeMs = t))
                    }
                }
        }
    }

    override fun onDestroy() {
        handler.removeCallbacks(tick)
        display?.release()
        reader?.close()
        projection?.stop()
        running.value = false
        super.onDestroy()
    }
}
